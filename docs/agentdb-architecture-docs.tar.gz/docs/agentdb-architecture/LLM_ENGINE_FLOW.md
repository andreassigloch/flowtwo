# 🔄 LLM Engine Informationsfluss mit agentDB Integration

## 🎯 Kompletter Flow: User Input → Master LLM → Tool Choice → agentDB → Agent Spawn

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         USER INPUT                                            │
│  "Erstelle Use Cases für ein Authentifizierungs-System"                      │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: REQUEST ROUTER                                                       │
│  ───────────────────────────────────────────────────────────────────────────│
│  POST /api/assistant/chat                                                     │
│  {                                                                            │
│    sessionId: "session-123",                                                 │
│    userId: "user-456",                                                       │
│    message: "Erstelle Use Cases für Auth...",                               │
│    context: {                                                                │
│      currentCanvas: "graph",                                                 │
│      currentSystemId: "uuid-of-system"                                       │
│    }                                                                          │
│  }                                                                            │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 2: KNOWLEDGE RETRIEVAL (agentDB Integration Point #1)                  │
│  ───────────────────────────────────────────────────────────────────────────│
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ agentDB.reflexion.retrieve("authentication use cases", k=5)         │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                               │
│  ✅ FOUND Similar Episodes?                                                  │
│  ┌───────────────┬──────────────────────────────────────────────────────┐   │
│  │ YES           │ NO                                                    │   │
│  │ ↓             │ ↓                                                     │   │
│  │ Return cache  │ Continue to Master LLM                                │   │
│  │ (Episode #42) │                                                       │   │
│  │ Similarity:   │                                                       │   │
│  │ 0.96          │                                                       │   │
│  │               │                                                       │   │
│  │ Skip LLM!     │                                                       │   │
│  │ Save $$$$     │                                                       │   │
│  └───────────────┴──────────────────────────────────────────────────────┘   │
│                                                                               │
│  Retrieved Episodes → Add to System Prompt Context                           │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 3: MASTER LLM (AIAssistantService)                                     │
│  ───────────────────────────────────────────────────────────────────────────│
│  ┌────────────────────────────────────────────────────────────────┐         │
│  │ System Prompt Construction (with agentDB context):              │         │
│  │ ────────────────────────────────────────────────────────────── │         │
│  │ 1. Ontology Rules (cached 88.7% cost reduction)                │         │
│  │ 2. Neo4j Current State (nodes/relationships)                   │         │
│  │ 3. agentDB Retrieved Episodes (similar past solutions) ✨      │         │
│  │ 4. Conversation History (last 10 messages)                     │         │
│  │ 5. User Expertise Level                                        │         │
│  └────────────────────────────────────────────────────────────────┘         │
│                                                                               │
│  LLM Provider: Claude 3.5 Sonnet / GPT-4                                     │
│  Temperature: 0.7                                                            │
│  Max Tokens: 4096                                                            │
│  Streaming: ENABLED                                                          │
│                                                                               │
│  User Message + System Prompt → LLM                                          │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 4: MASTER LLM ANALYSIS & DECISION                                      │
│  ───────────────────────────────────────────────────────────────────────────│
│                                                                               │
│  Master LLM Analyzes:                                                        │
│  ┌─────────────────────────────────────────────────────────────┐            │
│  │ • Task Complexity                                            │            │
│  │ • Available Knowledge (from agentDB)                         │            │
│  │ • Required Expertise                                         │            │
│  │ • Neo4j Current State                                        │            │
│  └─────────────────────────────────────────────────────────────┘            │
│                                                                               │
│  Decision Path:                                                              │
│  ┌──────────────────────┬──────────────────────┬───────────────────────┐    │
│  │ SIMPLE TASK          │ COMPLEX TASK         │ UNKNOWN TASK          │    │
│  │ (Confidence: >0.9)   │ (Requires Research)  │ (Need Exploration)    │    │
│  │ ↓                    │ ↓                    │ ↓                     │    │
│  │ Direct Answer        │ Spawn Specialist     │ Spawn Explorer        │    │
│  │ Generate Operations  │ Agent                │ Agent                 │    │
│  └──────────────────────┴──────────────────────┴───────────────────────┘    │
│                                                                               │
│  Output:                                                                     │
│  {                                                                           │
│    textResponse: "...",                                                      │
│    operations: [...],                                                        │
│    toolChoice: "spawn-agent" | "direct-answer",                             │
│    agentType: "requirements-specialist" | null                               │
│  }                                                                           │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                ┌────────────┴────────────┐
                │                         │
                ▼                         ▼
    ┌─────────────────────┐   ┌─────────────────────────┐
    │ DIRECT ANSWER       │   │ SPAWN AGENT             │
    │ (Simple Tasks)      │   │ (Complex/Unknown Tasks) │
    └─────────────────────┘   └─────────────────────────┘
                │                         │
                │                         │
                ▼                         ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  BRANCH A: DIRECT ANSWER PATH                                                │
│  ───────────────────────────────────────────────────────────────────────────│
│  Master LLM generates:                                                       │
│  ┌─────────────────────────────────────────────────────────────────┐        │
│  │ Text Response:                                                   │        │
│  │ "Hier sind die Use Cases für Authentifizierung:                 │        │
│  │  1. UC-LOGIN: Benutzer anmelden                                 │        │
│  │  2. UC-LOGOUT: Benutzer abmelden                                │        │
│  │  3. UC-REGISTER: Neuen Benutzer registrieren"                   │        │
│  │                                                                  │        │
│  │ Operations:                                                      │        │
│  │ [                                                                │        │
│  │   {                                                              │        │
│  │     type: "create",                                              │        │
│  │     nodeType: "UC",                                              │        │
│  │     tempId: "@UC1",                                              │        │
│  │     data: { Name: "Login", Descr: "Benutzer anmelden" }         │        │
│  │   },                                                             │        │
│  │   {                                                              │        │
│  │     type: "create-relationship",                                 │        │
│  │     relType: "INTERACTS",                                        │        │
│  │     sourceTempId: "@ACTOR_User",                                 │        │
│  │     targetTempId: "@UC1"                                         │        │
│  │   }                                                              │        │
│  │ ]                                                                │        │
│  └─────────────────────────────────────────────────────────────────┘        │
│                                                                               │
│  ↓ Go to STEP 6: STORE IN AGENTDB                                           │
└───────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────┐
│  BRANCH B: AGENT SPAWN PATH (agentDB Integration Point #2)                   │
│  ───────────────────────────────────────────────────────────────────────────│
│  Master LLM decides task needs specialized agent                             │
│                                                                               │
│  Agent Spawn Decision:                                                       │
│  ┌─────────────────────────────────────────────────────────────────┐        │
│  │ {                                                                │        │
│  │   taskType: "requirements-analysis",                             │        │
│  │   agentType: "requirements-specialist",                          │        │
│  │   context: {                                                     │        │
│  │     domain: "authentication",                                    │        │
│  │     knownPatterns: [...from agentDB...],                         │        │
│  │     systemContext: {...from Neo4j...}                            │        │
│  │   }                                                              │        │
│  │ }                                                                │        │
│  └─────────────────────────────────────────────────────────────────┘        │
│                                                                               │
│  ┌────────────────────────────────────────────────────────────────┐         │
│  │ Agent Types Available:                                          │         │
│  │ ──────────────────────────────────────────────────────────────│         │
│  │ • requirements-specialist  - Requirements Engineering          │         │
│  │ • architecture-designer    - System Architecture               │         │
│  │ • test-engineer            - Test Case Generation              │         │
│  │ • domain-explorer          - Unknown Domain Research           │         │
│  │ • ontology-validator       - SE Methodology Validation         │         │
│  └────────────────────────────────────────────────────────────────┘         │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 5: AGENT EXECUTION (Specialized Sub-Agent)                             │
│  ───────────────────────────────────────────────────────────────────────────│
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────┐           │
│  │ Agent Pre-Task:                                               │           │
│  │ ────────────────────────────────────────────────────────────│           │
│  │ 1. Query agentDB for relevant episodes                       │           │
│  │    agentDB.reflexion.retrieve(                               │           │
│  │      "authentication requirements",                           │           │
│  │      k=10,                                                    │           │
│  │      filters: {type: "requirements"}                          │           │
│  │    )                                                          │           │
│  │                                                               │           │
│  │ 2. Load skill library from agentDB                           │           │
│  │    agentDB.skill.search("requirements patterns", k=5)        │           │
│  │                                                               │           │
│  │ 3. Check causal edges                                        │           │
│  │    agentDB.causal.query(                                     │           │
│  │      cause: "authentication",                                │           │
│  │      effect: "security-requirements"                          │           │
│  │    )                                                          │           │
│  └──────────────────────────────────────────────────────────────┘           │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────┐           │
│  │ Agent Executes with Enhanced Context:                         │           │
│  │ ────────────────────────────────────────────────────────────│           │
│  │ • System Prompt (requirements specialist role)               │           │
│  │ • User Task (authentication use cases)                       │           │
│  │ • agentDB Episodes (10 similar past solutions)               │           │
│  │ • Skill Library (5 proven patterns)                          │           │
│  │ • Causal Knowledge (security implications)                   │           │
│  │ • Neo4j State (current system model)                         │           │
│  └──────────────────────────────────────────────────────────────┘           │
│                                                                               │
│  Agent produces detailed result:                                             │
│  {                                                                           │
│    textResponse: "Detaillierte Use Case Analyse...",                        │
│    operations: [...15 operations...],                                       │
│    confidence: 0.94,                                                         │
│    reasoning: "Based on 10 similar projects...",                            │
│    usedSkills: ["REQ-PATTERN-AUTH", "UC-DECOMP-STD"]                        │
│  }                                                                           │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────┐           │
│  │ Agent Post-Task:                                              │           │
│  │ ────────────────────────────────────────────────────────────│           │
│  │ 1. Store episode in agentDB                                  │           │
│  │    agentDB.reflexion.store(                                  │           │
│  │      task: "authentication-use-cases",                        │           │
│  │      reward: 0.94,                                            │           │
│  │      success: true,                                           │           │
│  │      critique: "Generated comprehensive use cases..."         │           │
│  │    )                                                          │           │
│  │                                                               │           │
│  │ 2. Update skill metrics                                      │           │
│  │    agentDB.skill.recordUsage("REQ-PATTERN-AUTH", success)    │           │
│  │                                                               │           │
│  │ 3. Propose causal edges                                      │           │
│  │    agentDB.causal.addEdge(                                   │           │
│  │      cause: "use-case-created",                              │           │
│  │      effect: "security-req-needed",                           │           │
│  │      uplift: 0.8                                              │           │
│  │    )                                                          │           │
│  └──────────────────────────────────────────────────────────────┘           │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 6: STORE KNOWLEDGE IN AGENTDB (Learning Loop)                          │
│  ───────────────────────────────────────────────────────────────────────────│
│                                                                               │
│  Store Successful Interaction:                                               │
│  ┌─────────────────────────────────────────────────────────────────┐        │
│  │ agentDB.reflexion.store({                                        │        │
│  │   sessionId: "session-123",                                      │        │
│  │   task: "create-authentication-use-cases",                       │        │
│  │   reward: 1.0,                                                   │        │
│  │   success: true,                                                 │        │
│  │   input: "Erstelle Use Cases für Auth...",                       │        │
│  │   output: {                                                      │        │
│  │     textResponse: "...",                                         │        │
│  │     operations: [...]                                            │        │
│  │   },                                                             │        │
│  │   critique: "Successfully generated 3 use cases with " +         │        │
│  │             "proper INTERACTS relationships",                    │        │
│  │   metadata: {                                                    │        │
│  │     domain: "authentication",                                    │        │
│  │     nodeTypes: ["UC"],                                           │        │
│  │     usedAgent: "requirements-specialist",                        │        │
│  │     tokensUsed: 850,                                             │        │
│  │     executionTime: 1200                                          │        │
│  │   }                                                              │        │
│  │ })                                                               │        │
│  └─────────────────────────────────────────────────────────────────┘        │
│                                                                               │
│  Automatic Learning (Background):                                            │
│  ┌─────────────────────────────────────────────────────────────────┐        │
│  │ 1. Skill Consolidation (runs periodically):                     │        │
│  │    agentDB.skill.consolidate({                                  │        │
│  │      minAttempts: 3,                                             │        │
│  │      minReward: 0.8,                                             │        │
│  │      timeWindow: 7 days                                          │        │
│  │    })                                                            │        │
│  │    → Creates "authentication-use-case-pattern" skill             │        │
│  │                                                                  │        │
│  │ 2. Causal Discovery (runs nightly):                             │        │
│  │    agentDB.learner.run({                                         │        │
│  │      minAttempts: 3,                                             │        │
│  │      minSuccessRate: 0.6                                         │        │
│  │    })                                                            │        │
│  │    → Discovers: "UC creation" → "REQ needed" (uplift: 0.75)     │        │
│  └─────────────────────────────────────────────────────────────────┘        │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 7: SEMANTIC ID RESOLUTION                                              │
│  ───────────────────────────────────────────────────────────────────────────│
│  SemanticIdResolver processes operations:                                    │
│  ┌─────────────────────────────────────────────────────────────────┐        │
│  │ Input:  @UC_Login, @ACTOR_User                                  │        │
│  │ ↓                                                                │        │
│  │ 1. Check if semantic ID exists in Neo4j                         │        │
│  │    Neo4j: MATCH (n) WHERE n.Name CONTAINS "Login"               │        │
│  │           AND n.type = "UC"                                      │        │
│  │ ↓                                                                │        │
│  │ 2. If exists → Return UUID                                      │        │
│  │    If new    → Generate tempId                                  │        │
│  │ ↓                                                                │        │
│  │ Output: tempId="temp-uuid-123"                                  │        │
│  └─────────────────────────────────────────────────────────────────┘        │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 8: OPERATION VALIDATION                                                │
│  ───────────────────────────────────────────────────────────────────────────│
│  ConversationModerator validates:                                            │
│  ┌─────────────────────────────────────────────────────────────────┐        │
│  │ ✅ All operations have valid types                              │        │
│  │ ✅ Required fields present (Name, Descr)                        │        │
│  │ ✅ Dependencies satisfied                                        │        │
│  │ ✅ Temp IDs properly referenced                                 │        │
│  │ ✅ Node types match ontology                                    │        │
│  └─────────────────────────────────────────────────────────────────┘        │
│                                                                               │
│  If invalid → Return error to user, DO NOT EXECUTE                           │
│  If valid   → Continue to execution                                          │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 9: OPERATION EXECUTION (Chunked)                                       │
│  ───────────────────────────────────────────────────────────────────────────│
│  ChunkExecutor processes in dependency order:                                │
│  ┌─────────────────────────────────────────────────────────────────┐        │
│  │ Chunk 1: Create nodes                                            │        │
│  │   → Neo4j: CREATE (n:UC {uuid, Name, Descr, ...})               │        │
│  │   → Store mapping: tempId → UUID                                │        │
│  │                                                                  │        │
│  │ Chunk 2: Create relationships (depends on Chunk 1)              │        │
│  │   → Resolve tempIds to UUIDs                                    │        │
│  │   → Neo4j: MATCH (a), (b) CREATE (a)-[:INTERACTS]->(b)          │        │
│  │                                                                  │        │
│  │ Chunk 3: Validate constraints                                   │        │
│  │   → ValidatorService.validateNode(uuid)                         │        │
│  │   → Check SE ontology rules                                     │        │
│  └─────────────────────────────────────────────────────────────────┘        │
│                                                                               │
│  Execution Results:                                                          │
│  {                                                                           │
│    success: true,                                                            │
│    executedOperations: 5,                                                    │
│    nodesCreated: 3,                                                          │
│    relationshipsCreated: 2,                                                  │
│    tempIdMappings: {                                                         │
│      "@UC1": "uuid-abc-123",                                                 │
│      "@UC2": "uuid-def-456"                                                  │
│    },                                                                        │
│    validationResults: [...]                                                  │
│  }                                                                           │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 10: RESPONSE DISTRIBUTION                                              │
│  ───────────────────────────────────────────────────────────────────────────│
│  ResponseDistributor sends updates to all canvases:                          │
│                                                                               │
│  ┌────────────────────┬──────────────────────┬────────────────────────┐     │
│  │ CHAT CANVAS        │ TEXT CANVAS          │ GRAPH CANVAS           │     │
│  │ ────────────────── │ ──────────────────── │ ──────────────────────│     │
│  │ Display AI message │ Add rows to UC table │ Add 3 UC nodes         │     │
│  │ "Ich habe 3 Use    │ ┌──────────────────┐ │ Add INTERACTS edges    │     │
│  │  Cases erstellt:"  │ │ Name   | Descr   │ │                        │     │
│  │                    │ │ Login  | Benutzer│ │ Update graph layout    │     │
│  │ Show metadata:     │ │ Logout | Benutzer│ │                        │     │
│  │ • 3 nodes created  │ │ Regist.| Neuen...│ │ Trigger validation     │     │
│  │ • 2 edges created  │ └──────────────────┘ │ icons                  │     │
│  └────────────────────┴──────────────────────┴────────────────────────┘     │
│                                                                               │
│  WebSocket broadcasts to all connected clients:                              │
│  ws.broadcast({                                                              │
│    type: 'graph-update',                                                     │
│    sessionId: 'session-123',                                                 │
│    updates: [...]                                                            │
│  })                                                                          │
└────────────────────────────┬─────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 11: USER SEES RESULT                                                   │
│  ───────────────────────────────────────────────────────────────────────────│
│  Real-time updates in UI:                                                    │
│  • Chat shows AI message                                                     │
│  • Graph canvas shows new nodes/edges                                        │
│  • Text canvas shows new table rows                                          │
│  • Validation icons appear                                                   │
│                                                                               │
│  User can:                                                                   │
│  • Continue conversation                                                     │
│  • Edit created elements                                                     │
│  • Request derivations (UC → Functions)                                      │
│  • Validate model                                                            │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Decision Flow: When to Use agentDB vs Direct Answer

```
User Query
    ↓
    ┌──────────────────────────────────────┐
    │ Master LLM Analyzes Query            │
    └────────────┬─────────────────────────┘
                 │
    ┌────────────┴────────────┐
    │ Query agentDB           │
    │ for similar episodes    │
    └────────────┬────────────┘
                 │
    ┌────────────▼────────────┐
    │ Episode Found?          │
    │ Similarity > 0.85?      │
    └────┬───────────────┬────┘
         │ YES           │ NO
         ▼               ▼
    ┌─────────────┐  ┌──────────────────┐
    │ RETURN      │  │ Assess           │
    │ CACHED      │  │ Complexity       │
    │ ANSWER      │  └────┬─────────────┘
    │             │       │
    │ Skip LLM!   │       ├─────────────────┬─────────────────┐
    │ 100x faster │       │                 │                 │
    │ 100x cheaper│       ▼                 ▼                 ▼
    └─────────────┘  ┌──────────┐    ┌──────────┐    ┌──────────┐
                     │ SIMPLE   │    │ COMPLEX  │    │ UNKNOWN  │
                     │ Direct   │    │ Spawn    │    │ Spawn    │
                     │ Answer   │    │ Specialist│   │ Explorer │
                     │          │    │ Agent    │    │ Agent    │
                     └──────────┘    └──────────┘    └──────────┘
```

---

## 📊 agentDB Integration Points Summary

| Integration Point | Purpose | Performance Impact |
|-------------------|---------|-------------------|
| **#1: Pre-Query Check** | Check for known answers | Skip LLM if match found (100x savings) |
| **#2: System Prompt Enhancement** | Add similar episodes to context | Better answers, fewer iterations |
| **#3: Agent Context Loading** | Provide specialized agent with knowledge | Higher success rate, proven patterns |
| **#4: Post-Execution Storage** | Store successful interactions | Build knowledge base over time |
| **#5: Skill Consolidation** | Extract reusable patterns | Automatic improvement |
| **#6: Causal Discovery** | Learn cause-effect relationships | Predictive suggestions |

---

## 🚀 Next: Implementation Code

See `agentdb-llm-integration.ts` for complete integration code.
